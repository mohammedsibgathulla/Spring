package com.springrest.basics.springrestbasics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringrestbasicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
