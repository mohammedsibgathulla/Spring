package com.springrest.basics.springrestbasics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestbasicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestbasicsApplication.class, args);
	}

}
